#include <WiFi.h>
#include <PubSubClient.h>
#include <ESP32Servo.h>

// WiFi settings for Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// MQTT settings
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;

const char* topic = "pesnext/w5/1HM25CR094/cmd";

// Pins
#define SERVO_PIN 18
#define LED_PIN 27
#define BUZZER_PIN 25

WiFiClient espClient;
PubSubClient client(espClient);
Servo door;

// State variables
int complaints = 0;
bool lockedOut = false;
bool doorOpen = false;

unsigned long lastComplaint = 0;
unsigned long lockoutStart = 0;
unsigned long doorOpenStart = 0;

void openDoor() {
  complaints = 0;

  if (lockedOut) return;

  door.write(90);
  doorOpen = true;
  doorOpenStart = millis();

  digitalWrite(LED_PIN, LOW);
  noTone(BUZZER_PIN);

  Serial.println("OPEN");
}

void denyAccess() {
  if (lockedOut) return;

  complaints++;

  digitalWrite(LED_PIN, HIGH);
  tone(BUZZER_PIN, 1000, 300);

  Serial.println("DENY");

  if (complaints >= 3) {
    lockedOut = true;
    lockoutStart = millis();

    tone(BUZZER_PIN, 1000);
    Serial.println("LOCKOUT STARTED");
  }
}

void callback(char* receivedTopic, byte* payload,
              unsigned int length) {

  String message = "";

  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }

  if (lockedOut) return;

  if (message == "open") {
    openDoor();
  }

  else if (message == "deny") {
    unsigned long now = millis();

    if (complaints == 0 ||
        now - lastComplaint >= 2000) {

      denyAccess();
      lastComplaint = now;
    }
  }
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Connecting MQTT...");

    if (client.connect("SmartDoorLock_1HM25CR094")) {
      Serial.println("Connected!");

      client.subscribe(topic);
    } else {
      Serial.println("Retrying...");
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  door.attach(SERVO_PIN);
  door.write(0);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi connected!");

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  unsigned long now = millis();

  // Door closes after 5 seconds
  if (doorOpen && now - doorOpenStart >= 5000) {
    door.write(0);
    doorOpen = false;
    Serial.println("DOOR CLOSED");
  }

  // Lockout lasts 10 seconds
  if (lockedOut && now - lockoutStart >= 10000) {
    lockedOut = false;
    complaints = 0;

    noTone(BUZZER_PIN);
    digitalWrite(LED_PIN, LOW);

    Serial.println("LOCKOUT ENDED");
  }

  delay(10);
}
